# Café Bordeaux — demo website

A single-page café website demo (burgundy, olive and cream). Everything is in `index.html`, photos included.

## Put it online with GitHub Pages
1. Create a new public repository on GitHub, for example `cafe-bordeaux`.
2. Upload every file from this folder to the repository (`index.html`, `.nojekyll`, `README.md`). Keep the name `index.html`.
3. Open the repository's Settings, then Pages.
4. Under Source choose "Deploy from a branch", pick the `main` branch and the `/ (root)` folder, then Save.
5. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/cafe-bordeaux/`.

## Before it goes live for real
- Replace the reference photos with licensed or the café's own photos.
- Replace the placeholder name, menu, prices, address and opening hours.
- The reservation form is a demo and does not send anything.
